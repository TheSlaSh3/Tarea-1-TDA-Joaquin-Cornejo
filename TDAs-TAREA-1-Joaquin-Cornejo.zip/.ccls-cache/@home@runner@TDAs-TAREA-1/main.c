#include "tdas/list.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

typedef struct{
  int segundos;
  int minutos;
  int horas;
}tipoTiempo;

typedef struct{
  char nombre[100];
  int edad;
  char sintoma[50];
  char prioridad[10];
  tipoTiempo llegada;
}tipoPaciente;

int largo(List *listaPacientes)
{
  int contador = 0;
  tipoPaciente *paciente = list_first(listaPacientes);
  
  while(paciente != NULL)
    {
      contador ++;
      paciente = list_next(listaPacientes);
    }
  return contador;
}

void limpiarPantalla() { system("clear"); }

void presioneTeclaParaContinuar() {
  puts("Presione una tecla para continuar...");
  getchar(); // Consume el '\n' del buffer de entrada
  getchar(); // Espera a que el usuario presione una tecla
}

// Menú principal
int comparar(void *A , void *B) {
  tipoPaciente *ptrPaciente1 = (tipoPaciente *)A;
  tipoPaciente *ptrPaciente2 = (tipoPaciente *)B;
  int prioridad1, prioridad2;
  
  if(strcmp(ptrPaciente1->prioridad,"alta")== 0){
    prioridad1 = 3;
  }
  else if(strcmp(ptrPaciente1->prioridad,"media")== 0){
    prioridad1 = 2;
  }
  else if(strcmp(ptrPaciente1->prioridad,"baja")== 0){
    prioridad1 = 1;
  }
  if(strcmp(ptrPaciente2->prioridad,"alta")== 0){
    prioridad2 = 3;
  }
  else if(strcmp(ptrPaciente2->prioridad,"media")== 0){
    prioridad2 = 2;
  }
  else if(strcmp(ptrPaciente2->prioridad,"baja")== 0){
    prioridad2 = 1;
  }
  if(prioridad1 != prioridad2){
    return prioridad1 > prioridad2;
  }
  if (ptrPaciente1->llegada.horas != ptrPaciente2->llegada.horas) {
      return ptrPaciente1->llegada.horas < ptrPaciente2->llegada.horas;
  } 
  else if (ptrPaciente1->llegada.minutos != ptrPaciente2->llegada.minutos) {
    return ptrPaciente1->llegada.minutos < ptrPaciente2->llegada.minutos;
  } 
  else {
    return ptrPaciente1->llegada.segundos < ptrPaciente2->llegada.segundos;
  }
}

void minus(char *texto) {
  while(*texto){
    *texto = tolower(*texto);
    texto++;
  }
}

void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir");
}

void obtenerTiempoActual(tipoTiempo *tiempo) {
  setenv("TZ", "CLT+4", 1); // para cambiar la zona horaria a chile 
  tzset(); //para actualizar la hora
  
  time_t tiempoActual;
  struct tm *infoTiempo;

  time(&tiempoActual);
  infoTiempo = localtime(&tiempoActual);

  tiempo->horas = infoTiempo->tm_hour;
  tiempo->minutos = infoTiempo->tm_min;
  tiempo->segundos = infoTiempo->tm_sec;
}

void mostrarPaciente(tipoPaciente *paciente) {
  printf("Nombre: %s\n", paciente->nombre);
  printf("Edad: %d\n", paciente->edad);
  printf("Sintoma: %s\n", paciente->sintoma);
  printf("Hora de llegada: %02d:%02d:%02d\n\n", 
         paciente->llegada.horas, paciente->llegada.minutos,                       paciente->llegada.segundos);
}

void registrar_paciente(List *listaPacientes) {
  limpiarPantalla();
  tipoPaciente *paciente = (tipoPaciente*)malloc(sizeof(tipoPaciente));

  int nombreValido;
  do
  {
    nombreValido = 1;
    printf("Ingrese el nombre del paciente: \n");
    scanf(" %[^\n]100s", paciente->nombre);
    for(int i = 0; paciente->nombre[i] != '\0'; i++)
      {
        if(isdigit(paciente->nombre[i]))
        {
          printf("Error: Ingrese solo caracteres para el nombre.\n");
          nombreValido = 0;
          break;
        }
      }
    if (nombreValido)
    {
      printf("Nombre ingresado correctamente: %s\n\n", paciente->nombre);
    }
  }while(!nombreValido);
  
  int edadValida;//Si sigue siendo 1 entonces 
  do 
    {
      edadValida = 1;
      printf("Ingrese la edad del paciente: \n");//EDAD
      char edadStr[100];
      scanf(" %[^\n]", edadStr);

      for(int i = 0; edadStr[i] != '\0'; i++)
      {
        if (!isdigit(edadStr[i]))
        {
          printf("Error: Ingrese solo dígitos para la edad.\n");
          edadValida = 0; //No son todos los caracteres son dígitos.
          break;
        }
      }
    if (edadValida)
    {
      paciente->edad = atoi(edadStr); //la edadStr se convierte en entero
      printf("Edad ingresada correctamente: %d\n\n", paciente->edad);
    }
      }while (!edadValida);
  
  int sintomaValido;//SINTOMA
  do
  {
    sintomaValido = 1;
    printf("Ingrese el sintoma del paciente: \n");
    scanf(" %[^\n]50s", paciente->sintoma);
    for(int i = 0; paciente->sintoma[i] != '\0'; i++)
      {
        if(isdigit(paciente->sintoma[i]))
        {
          printf("Error: Ingrese solo caracteres para el sintoma.\n");
          sintomaValido = 0;
          break;
        }
      }
    if (sintomaValido)
    {
      printf("Sintoma ingresado correctamente: %s\n\n", paciente->sintoma);
    }
  }while(!sintomaValido);
  
  obtenerTiempoActual(&paciente->llegada);
  
  printf("\n");
  //asignación automatica de prioridad baja, de forma optimizada.
  snprintf(paciente->prioridad, sizeof(paciente->prioridad), "baja");
  //Ahora hay que registrar el tiempo de llegada.
  
  mostrarPaciente(paciente); 
  list_pushBack(listaPacientes, paciente);
}

void asignarPrioridad(List *listaPacientes) {
  char nombreBusqueda[100];
  int pacienteEncontrado;
  
  do {
      printf("Ingrese el nombre del paciente: ");
      scanf(" %[^\n]", nombreBusqueda);

      tipoPaciente *paciente = list_first(listaPacientes);
      pacienteEncontrado = 0; 

      while (paciente != NULL) {
          if (strcmp(nombreBusqueda, paciente->nombre) == 0) 
          {
              pacienteEncontrado = 1; 
              printf("Que prioridad deseas asignar: ");

              char prioridadNueva[10];
              int prioridadValida = 1;

              scanf(" %[^\n]", prioridadNueva);

              for (int i = 0; prioridadNueva[i] != '\0'; i++) {
                  if (!isalpha(prioridadNueva[i])) {
                      printf("Error: La prioridad debe contener solo caracteres.\n");
                      prioridadValida = 0;
                      break;
                  }
              }

              if (prioridadValida) {
                  strcpy(paciente->prioridad, prioridadNueva);
                  printf("Prioridad asignada correctamente.\n");
              }
            list_popCurrent(listaPacientes);
            list_sortedInsert(listaPacientes,paciente,comparar); 
            return;
          }       
          paciente = list_next(listaPacientes);
      }
  } while (!pacienteEncontrado);
} 

void mostrar_lista_pacientes(List *listaPacientes) {

  // Mostrar pacientes en la cola de espera
  printf("\nPacientes en espera: \n");
  tipoPaciente *paciente = list_first(listaPacientes);
  while (paciente != NULL) {
    mostrarPaciente(paciente);
    paciente = list_next(listaPacientes);
  }
  // Aquí implementarías la lógica para recorrer y mostrar los pacientes
}

void antederSiguiente(List *listaPacientes) {
  if (largo(listaPacientes) == 0)
  {
    printf("No quedan pacientes para atender.\n");
    return;
  }
  
  tipoPaciente *paciente = list_first(listaPacientes);

  printf("Paciente a atender: \n");
  mostrarPaciente(paciente);
  list_popFront(listaPacientes);
  
  int tamanio = largo(listaPacientes);
  if (tamanio == 0)
  {
    printf("No quedan pacientes para atender.\n");
  }
  else  
  {
    printf("Quedan %d pacientes para atender.\n", tamanio);
  }
}

void mostrarPacientePrioridad(List *listaPacientes) {
  char prioridadBusqueda[10];
  int prioridadValida = 0;
  
  printf("Prioridad a buscar: ");
  scanf(" %[^\n]", prioridadBusqueda);
  minus(prioridadBusqueda);
  
  tipoPaciente *paciente = list_first(listaPacientes);
  while (paciente != NULL)
  {
    if(strcmp(prioridadBusqueda, paciente->prioridad) == 0)
    {
      mostrarPaciente(paciente);
      prioridadValida = 1;
    }
    paciente = list_next(listaPacientes);
  }
  if(!prioridadValida)
  {
    printf("\nPrioridad no encontrada.\n");
  }
}

int main() { //############################################################################
  char opcion;
  List *pacientes = list_create(); // puedes usar una lista para gestionar los pacientes

  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf(" %c", &opcion); // Nota el espacio antes de %c para consumir el
                           // newline anterior

    switch (opcion) {
    case '1':
      registrar_paciente(pacientes);
      break;
    case '2':
      asignarPrioridad(pacientes);
      // Lógica para asignar prioridad
      break;
    case '3':
      mostrar_lista_pacientes(pacientes);
      break;
    case '4':
      antederSiguiente(pacientes);
      // Lógica para atender al siguiente paciente
      break;
    case '5':
      mostrarPacientePrioridad(pacientes);
      // Lógica para mostrar pacientes por prioridad
      break;
    case '6':
      puts("Saliendo del sistema de gestión hospitalaria...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
    presioneTeclaParaContinuar();

  } while (opcion != '6');

  // Liberar recursos, si es necesario
  list_clean(pacientes);

  return 0;
}
